import { motion } from "framer-motion";
import { Award, Globe, Clock } from "lucide-react";

export default function About() {
  const skills = [
    "React & Next.js",
    "Adobe Creative Suite", 
    "Content Strategy",
    "SEO Writing",
    "UI/UX Design",
    "E-commerce"
  ];

  const highlights = [
    {
      icon: Award,
      title: "Multi-Disciplinary Expertise",
      description: "Studio Scribe 5 offers a rare combination of technical development skills, creative design vision, and persuasive writing ability.",
      iconBg: "bg-primary/10",
      iconColor: "text-primary"
    },
    {
      icon: Globe,
      title: "Global Perspective", 
      description: "Our team has experience working with clients across 25+ countries, understanding diverse markets and cultural nuances.",
      iconBg: "bg-accent/10",
      iconColor: "text-accent"
    },
    {
      icon: Clock,
      title: "Proven Track Record",
      description: "Studio Scribe 5 consistently delivers projects on time and exceeds client expectations with measurable results.",
      iconBg: "bg-secondary",
      iconColor: "text-primary"
    }
  ];

  return (
    <section id="about" className="bg-muted py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground">About Studio Scribe 5</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Founded and led by Augustine Genesis Koodanga, Studio Scribe 5 is a premier creative agency with over 8 years of experience delivering exceptional results across 
                copywriting, web development, and graphic design. Based globally, we serve clients worldwide with unmatched expertise.
              </p>
            </div>
            
            <div className="space-y-6">
              {highlights.map((highlight, index) => {
                const Icon = highlight.icon;
                return (
                  <motion.div
                    key={highlight.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.2 }}
                    className="flex items-start space-x-4"
                  >
                    <div className={`w-12 h-12 ${highlight.iconBg} rounded-xl flex items-center justify-center flex-shrink-0`}>
                      <Icon className={`${highlight.iconColor} w-6 h-6`} />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-foreground mb-2">{highlight.title}</h3>
                      <p className="text-muted-foreground">{highlight.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="flex flex-wrap gap-3"
            >
              {skills.map((skill) => (
                <span 
                  key={skill}
                  className="bg-card border border-border px-4 py-2 rounded-lg text-sm text-card-foreground"
                >
                  {skill}
                </span>
              ))}
            </motion.div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <img 
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=700" 
              alt="Professional working on laptop in modern office" 
              className="rounded-2xl shadow-xl w-full h-auto"
            />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 1.0 }}
              className="absolute top-6 right-6 bg-card border border-border rounded-xl p-4 shadow-lg"
            >
              <div className="text-center">
                <div className="text-2xl font-bold text-card-foreground">8+</div>
                <div className="text-xs text-muted-foreground">Years Experience</div>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 1.2 }}
              className="absolute bottom-6 left-6 bg-card border border-border rounded-xl p-4 shadow-lg"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                  <span className="text-accent-foreground text-sm">★</span>
                </div>
                <div>
                  <div className="text-sm font-semibold text-card-foreground">5.0 Rating</div>
                  <div className="text-xs text-muted-foreground">From 150+ Clients</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
