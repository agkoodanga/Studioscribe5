import { motion } from "framer-motion";
import { Calendar } from "lucide-react";

export default function Blog() {
  const blogPosts = [
    {
      title: "10 Copywriting Techniques That Convert Global Audiences",
      description: "Discover the psychology-backed writing strategies that drive action across different cultures and markets.",
      image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      category: "Copywriting",
      readTime: "5 min read",
      date: "March 15, 2024",
      categoryColor: "bg-primary/10 text-primary"
    },
    {
      title: "Building Fast, Global Websites: A Technical Deep Dive",
      description: "Learn how to optimize website performance for international audiences with CDN strategies and modern frameworks.",
      image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      category: "Web Dev",
      readTime: "8 min read", 
      date: "March 10, 2024",
      categoryColor: "bg-accent/10 text-accent-foreground"
    },
    {
      title: "Color Psychology in Global Brand Design",
      description: "Understanding how color choices impact perception across different cultures and how to design for global markets.",
      image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      category: "Design",
      readTime: "6 min read",
      date: "March 5, 2024", 
      categoryColor: "bg-secondary text-secondary-foreground"
    }
  ];

  return (
    <section className="bg-muted py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground">Latest Insights</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Industry expertise and actionable insights from the world of digital creativity
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <motion.article
              key={post.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="bg-card rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow group cursor-pointer"
              data-testid={`blog-post-${post.title.toLowerCase().replace(/\s+/g, '-').substring(0, 30)}`}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${post.categoryColor}`}>
                      {post.category}
                    </span>
                    <span className="text-xs text-muted-foreground">{post.readTime}</span>
                  </div>
                  <h3 className="text-lg font-semibold text-card-foreground leading-tight">
                    {post.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {post.description}
                  </p>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Calendar className="w-4 h-4 mr-2" />
                    <span>{post.date}</span>
                  </div>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
        
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <button 
            className="bg-primary text-primary-foreground px-8 py-4 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
            data-testid="button-view-all-articles"
          >
            View All Articles
          </button>
        </motion.div>
      </div>
    </section>
  );
}
