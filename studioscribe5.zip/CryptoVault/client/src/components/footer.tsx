import { motion } from "framer-motion";
import { SiLinkedin, SiX, SiBehance } from "react-icons/si";
import { Mail, Phone, Globe, Clock } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const serviceLinks = [
    "Professional Copywriting",
    "Web Development",
    "Graphic Design",
    "Content Strategy",
    "Brand Development"
  ];

  const resourceLinks = [
    "Portfolio",
    "Case Studies", 
    "Blog",
    "FAQ",
    "Free Resources"
  ];

  return (
    <footer className="bg-card border-t border-border py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
          >
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">S5</span>
              </div>
              <div>
                <h3 className="text-lg font-bold text-card-foreground">Studio Scribe 5</h3>
                <p className="text-xs text-muted-foreground">Global Creative Services</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Professional copywriting, web development, and graphic design services for businesses worldwide.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="w-8 h-8 bg-muted rounded-full flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
                data-testid="social-linkedin"
              >
                <SiLinkedin className="w-4 h-4" />
              </a>
              <a 
                href="#" 
                className="w-8 h-8 bg-muted rounded-full flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
                data-testid="social-twitter"
              >
                <SiX className="w-4 h-4" />
              </a>
              <a 
                href="#" 
                className="w-8 h-8 bg-muted rounded-full flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
                data-testid="social-behance"
              >
                <SiBehance className="w-4 h-4" />
              </a>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h4 className="font-semibold text-card-foreground mb-4">Services</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {serviceLinks.map((link) => (
                <li key={link}>
                  <button 
                    onClick={() => scrollToSection("services")}
                    className="hover:text-foreground transition-colors text-left"
                    data-testid={`footer-service-${link.toLowerCase().replace(' ', '-')}`}
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h4 className="font-semibold text-card-foreground mb-4">Resources</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {resourceLinks.map((link) => (
                <li key={link}>
                  <button 
                    onClick={() => scrollToSection(link === "Portfolio" ? "portfolio" : "blog")}
                    className="hover:text-foreground transition-colors text-left"
                    data-testid={`footer-resource-${link.toLowerCase().replace(' ', '-')}`}
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <h4 className="font-semibold text-card-foreground mb-4">Get in Touch</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-primary flex-shrink-0" />
                <a 
                  href="mailto:agkoodanga@gmail.com" 
                  className="hover:text-foreground transition-colors"
                  data-testid="contact-email"
                >
                  agkoodanga@gmail.com
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-primary flex-shrink-0" />
                <span data-testid="contact-phone">+234 912 435 2286 (WhatsApp)</span>
              </li>
              <li className="flex items-center space-x-3">
                <Globe className="w-4 h-4 text-primary flex-shrink-0" />
                <span>Available Worldwide</span>
              </li>
              <li className="flex items-center space-x-3">
                <Clock className="w-4 h-4 text-primary flex-shrink-0" />
                <span>24/7 Project Support</span>
              </li>
            </ul>
          </motion.div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="border-t border-border pt-8 mt-12"
        >
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-muted-foreground">© 2024 Studio Scribe 5. All rights reserved.</p>
            <div className="flex space-x-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors" data-testid="link-privacy">Privacy Policy</a>
              <a href="#" className="hover:text-foreground transition-colors" data-testid="link-terms">Terms of Service</a>
              <a href="#" className="hover:text-foreground transition-colors" data-testid="link-cookies">Cookie Policy</a>
            </div>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}
