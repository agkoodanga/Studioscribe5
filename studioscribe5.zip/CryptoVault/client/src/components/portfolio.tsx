import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Calendar } from "lucide-react";

export default function Portfolio() {
  const [activeFilter, setActiveFilter] = useState("All");
  
  const portfolioItems = [
    {
      title: "TechStart Global Platform",
      description: "Complete brand overhaul including copywriting and web development for a Silicon Valley startup expanding internationally.",
      image: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      tags: ["Copywriting", "Web Dev"],
      date: "March 2024"
    },
    {
      title: "FinanceFlow Branding",
      description: "Complete visual identity design for a European fintech company, including logo, business cards, and marketing materials.",
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      tags: ["Graphic Design"],
      date: "February 2024"
    },
    {
      title: "EcoMarket E-commerce",
      description: "Full-stack e-commerce development with persuasive product copy for an Australian sustainable goods marketplace.",
      image: "https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      tags: ["Web Dev", "Copywriting"],
      date: "January 2024"
    },
    {
      title: "HealthPlus Digital Transformation",
      description: "Complete digital overhaul including web platform, content strategy, and visual branding for a Canadian healthcare provider.",
      image: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      tags: ["All Services"],
      date: "December 2023"
    },
    {
      title: "RetailMax Campaign",
      description: "Multi-channel marketing campaign design including social media assets, print materials, and digital advertising for UK retail chain.",
      image: "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      tags: ["Graphic Design"],
      date: "November 2023"
    },
    {
      title: "TravelWise Content Strategy",
      description: "Comprehensive content strategy and copywriting for a global travel platform targeting multiple international markets.",
      image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      tags: ["Copywriting"],
      date: "October 2023"
    }
  ];

  const filters = ["All", "Copywriting", "Web Dev", "Graphic Design"];

  const filteredItems = activeFilter === "All" 
    ? portfolioItems 
    : portfolioItems.filter(item => 
        item.tags.some(tag => tag.includes(activeFilter))
      );

  const getTagColor = (tag: string) => {
    switch (tag) {
      case "Copywriting": return "bg-primary/10 text-primary";
      case "Web Dev": return "bg-accent/10 text-accent-foreground";
      case "Graphic Design": return "bg-secondary text-secondary-foreground";
      case "All Services": return "bg-secondary text-secondary-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <section id="portfolio" className="bg-background py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground">Featured Work</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A selection of recent projects showcasing the breadth and quality of our creative services
          </p>
        </motion.div>
        
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                activeFilter === filter
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
              data-testid={`filter-${filter.toLowerCase().replace(' ', '-')}`}
            >
              {filter}
            </button>
          ))}
        </div>
        
        <motion.div layout className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence>
            {filteredItems.map((item) => (
              <motion.div
                key={item.title}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                whileHover={{ y: -5 }}
                className="bg-card rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow group cursor-pointer"
                data-testid={`portfolio-item-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="relative overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center flex-wrap gap-2 mb-3">
                    {item.tags.map((tag) => (
                      <span 
                        key={tag} 
                        className={`px-3 py-1 rounded-full text-xs font-medium ${getTagColor(tag)}`}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="text-lg font-semibold text-card-foreground mb-2">{item.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{item.description}</p>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4 mr-2" />
                    <span>Completed {item.date}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <button 
            className="bg-primary text-primary-foreground px-8 py-4 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
            data-testid="button-view-full-portfolio"
          >
            View Full Portfolio
          </button>
        </motion.div>
      </div>
    </section>
  );
}
