import { motion } from "framer-motion";
import { Check, Star } from "lucide-react";

export default function Pricing() {
  const packages = [
    {
      name: "Essential",
      description: "Perfect for small businesses and startups",
      price: "$2,500",
      priceNote: "Starting price",
      features: [
        "Single service focus",
        "2 revision rounds", 
        "2-week delivery",
        "Email support"
      ],
      buttonText: "Get Started",
      buttonColor: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
      popular: false
    },
    {
      name: "Professional",
      description: "Comprehensive solution for growing businesses",
      price: "$5,500",
      priceNote: "Starting price",
      features: [
        "Two integrated services",
        "Unlimited revisions",
        "3-week delivery", 
        "Priority support",
        "Strategy consultation"
      ],
      buttonText: "Get Started",
      buttonColor: "bg-primary text-primary-foreground hover:bg-primary/90",
      popular: true
    },
    {
      name: "Enterprise",
      description: "Full-service solution for established companies",
      price: "$12,000",
      priceNote: "Starting price", 
      features: [
        "All three services integrated",
        "Unlimited revisions",
        "4-week delivery",
        "Dedicated project manager",
        "Ongoing maintenance",
        "Global market analysis"
      ],
      buttonText: "Contact Sales",
      buttonColor: "bg-accent text-accent-foreground hover:bg-accent/90",
      popular: false
    }
  ];

  return (
    <section className="bg-background py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground">Service Packages</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Flexible packages designed to meet your specific needs and budget
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className={`bg-card rounded-2xl p-8 shadow-lg relative ${
                pkg.popular ? "border-2 border-primary" : "border border-border"
              }`}
              data-testid={`pricing-package-${pkg.name.toLowerCase()}`}
            >
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-medium flex items-center">
                    <Star className="w-4 h-4 mr-1" />
                    Most Popular
                  </div>
                </div>
              )}
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl font-bold text-card-foreground mb-2">{pkg.name}</h3>
                  <p className="text-muted-foreground mb-4">{pkg.description}</p>
                  <div className="text-3xl font-bold text-primary">{pkg.price}</div>
                  <p className="text-sm text-muted-foreground">{pkg.priceNote}</p>
                </div>
                
                <ul className="space-y-3">
                  {pkg.features.map((feature) => (
                    <li key={feature} className="flex items-center text-sm">
                      <Check className="text-accent w-5 h-5 mr-3 flex-shrink-0" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button 
                  className={`w-full py-3 rounded-lg font-semibold transition-colors ${pkg.buttonColor}`}
                  data-testid={`button-${pkg.buttonText.toLowerCase().replace(' ', '-')}-${pkg.name.toLowerCase()}`}
                >
                  {pkg.buttonText}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
