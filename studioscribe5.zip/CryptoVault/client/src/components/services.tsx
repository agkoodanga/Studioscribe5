import { motion } from "framer-motion";
import { PenTool, Code, Palette } from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: PenTool,
      title: "Professional Copywriting",
      description: "Compelling copy that converts. From web content and marketing materials to brand messaging that resonates with your global audience.",
      image: "https://pixabay.com/get/gc4cef7cc5981d9d3dca022c1dd7ae60394fc9e83464dfaf118ab94c9b4903069221bb760c6428a1558bc848407c326105fb3bb1b736db2604d7e3fcdaabccc5f_1280.jpg",
      features: [
        "Website & Landing Page Copy",
        "Marketing & Sales Materials", 
        "Brand Voice & Messaging",
        "SEO-Optimized Content"
      ],
      buttonColor: "bg-primary text-primary-foreground hover:bg-primary/90",
      iconBg: "bg-primary/10",
      iconColor: "text-primary"
    },
    {
      icon: Code,
      title: "Web Development",
      description: "Modern, responsive websites and web applications built with the latest technologies. Fast, secure, and optimized for global performance.",
      image: "https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      features: [
        "Custom Website Development",
        "E-commerce Solutions",
        "Web App Development", 
        "Performance Optimization"
      ],
      buttonColor: "bg-accent text-accent-foreground hover:bg-accent/90",
      iconBg: "bg-accent/10",
      iconColor: "text-accent"
    },
    {
      icon: Palette,
      title: "Graphic Design",
      description: "Visual identity and design that speaks to your audience. From logos and branding to marketing materials that make lasting impressions.",
      image: "https://images.unsplash.com/photo-1558655146-d09347e92766?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      features: [
        "Logo & Brand Identity",
        "Marketing Materials",
        "UI/UX Design",
        "Print & Digital Assets"
      ],
      buttonColor: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
      iconBg: "bg-secondary",
      iconColor: "text-primary"
    }
  ];

  return (
    <section id="services" className="bg-muted py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground">Comprehensive Creative Services</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Three specialized disciplines working in harmony to elevate your brand and digital presence
          </p>
        </motion.div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="bg-card rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="space-y-6">
                  <div className={`w-16 h-16 ${service.iconBg} rounded-xl flex items-center justify-center`}>
                    <Icon className={`${service.iconColor} w-8 h-8`} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-card-foreground mb-3">{service.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                  
                  <img 
                    src={service.image} 
                    alt={`${service.title} workspace`} 
                    className="rounded-lg w-full h-48 object-cover"
                  />
                  
                  <ul className="space-y-2">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center text-sm text-muted-foreground">
                        <span className="text-accent mr-3">✓</span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <button 
                    className={`w-full py-3 rounded-lg font-semibold transition-colors ${service.buttonColor}`}
                    data-testid={`button-learn-more-${service.title.toLowerCase().replace(' ', '-')}`}
                  >
                    Learn More
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
