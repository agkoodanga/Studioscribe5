import { motion } from "framer-motion";
import { Star } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      rating: 5,
      content: "Studio Scribe 5 transformed our entire digital presence. Their copywriting was persuasive, the website is lightning-fast, and the design is absolutely stunning. Our conversion rate increased by 180%.",
      author: "Sarah Johnson",
      title: "CEO, TechFlow Solutions (USA)",
      initials: "SJ"
    },
    {
      rating: 5,
      content: "Working with Studio Scribe 5 was a game-changer. They understood our European market perfectly and delivered a brand identity that resonates across all our target countries.",
      author: "Marcus Klein",
      title: "Founder, GreenEnergy AG (Germany)",
      initials: "MK"
    },
    {
      rating: 5,
      content: "The quality of work is exceptional. Studio Scribe 5 delivered our e-commerce platform on time, with compelling product descriptions that significantly boosted our sales.",
      author: "Lisa Chen", 
      title: "Director, EcoMarket (Australia)",
      initials: "LC"
    }
  ];

  return (
    <section id="testimonials" className="bg-background py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground">What Clients Say</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Trusted by businesses worldwide to deliver exceptional creative solutions
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.author}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="bg-card rounded-2xl p-8 shadow-lg"
              data-testid={`testimonial-${testimonial.author.toLowerCase().replace(' ', '-')}`}
            >
              <div className="space-y-6">
                <div className="flex text-accent">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <p className="text-muted-foreground italic leading-relaxed">
                  "{testimonial.content}"
                </p>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                    <span className="text-muted-foreground font-semibold">{testimonial.initials}</span>
                  </div>
                  <div>
                    <div className="font-semibold text-card-foreground">{testimonial.author}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.title}</div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
