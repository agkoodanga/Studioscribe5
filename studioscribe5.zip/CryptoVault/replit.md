# Studio Scribe 5 - Portfolio Website

## Overview

This is a professional portfolio website for Studio Scribe 5, a multi-service creative agency founded and led by CEO Augustine Genesis Koodanga (agkoodanga@gmail.com), offering copywriting, web development, and graphic design services globally. The application is built as a full-stack web application with a React frontend and Express.js backend, featuring a modern landing page with service showcases, portfolio displays, client testimonials, and a contact form system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, using Vite as the build tool and development server
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and API interactions
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **Animations**: Framer Motion for smooth page transitions and interactive elements
- **Styling**: Tailwind CSS with custom design tokens and CSS variables for theming

### Backend Architecture
- **Runtime**: Node.js with Express.js web framework
- **Language**: TypeScript with ES modules
- **Database Layer**: Drizzle ORM configured for PostgreSQL with schema-first approach
- **Storage**: Currently using in-memory storage (MemStorage) with interface design allowing easy migration to PostgreSQL
- **API Design**: RESTful API with structured error handling and request logging middleware
- **Development**: Hot reload development server with Vite integration for SSR-like development experience

### Component Structure
- **Landing Page**: Single-page application with multiple sections (hero, services, portfolio, about, testimonials, pricing, blog, contact)
- **Form Handling**: Contact form with multi-step validation, service selection, and submission tracking
- **Responsive Design**: Mobile-first approach with adaptive layouts across all screen sizes
- **Performance**: Optimized with code splitting, lazy loading, and efficient re-rendering patterns

### Data Schema
- **Contact Submissions**: Captures lead information including personal details, company info, requested services, project details, and budget preferences
- **Validation**: Zod schemas for both frontend and backend validation ensuring data consistency
- **Type Safety**: Full TypeScript integration with inferred types from database schema

### Development Workflow
- **Build Process**: Vite for frontend bundling, esbuild for backend compilation
- **Database Migration**: Drizzle Kit for schema management and database migrations
- **Environment**: Separate development and production configurations with environment variable management

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form, TanStack Query for modern React patterns
- **Build Tools**: Vite for development and bundling, esbuild for backend compilation, TypeScript compiler
- **Backend Framework**: Express.js with session management and middleware support

### UI and Styling
- **Component Library**: Radix UI primitives for accessible, unstyled components
- **Styling**: Tailwind CSS with PostCSS for utility-first styling approach
- **Icons**: Lucide React for consistent iconography, React Icons for brand icons
- **Animations**: Framer Motion for declarative animations and page transitions

### Database and Validation
- **ORM**: Drizzle ORM for type-safe database operations and migrations
- **Database Driver**: @neondatabase/serverless for PostgreSQL connectivity (production)
- **Validation**: Zod for runtime type checking and form validation
- **Schema Management**: Drizzle Zod for automatic schema validation generation

### Development and Quality
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **Date Handling**: date-fns for date manipulation and formatting
- **Utilities**: clsx and tailwind-merge for conditional styling, class-variance-authority for component variants

### Replit Integration
- **Development Plugins**: @replit/vite-plugin-runtime-error-modal and @replit/vite-plugin-cartographer for enhanced development experience
- **Environment**: Configured for seamless Replit deployment and development workflow